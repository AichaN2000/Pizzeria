using Microsoft.EntityFrameworkCore;

namespace Pizzeria.Models
{
    public class PizzaEhod
    {
        public int Id { get; set; }
        public string? Nom { get; set; }
        public string? Description { get; set; }
    }

    class PizzaEhodDB : DbContext
    {
        public PizzaEhodDB(DbContextOptions options) : base(options) { }
        public DbSet<PizzaEhod> Pizzas { get; set; } = null!;
    }
}