using Microsoft.OpenApi.Models;
using Microsoft.EntityFrameworkCore;
using Pizzeria.Models;

var builder = WebApplication.CreateBuilder(args);

// Ajouter la chaîne de connexion pour SQLite
var connectionString = builder.Configuration.GetConnectionString("Pizzas") ?? "Data Source=Pizzas.db";

// Configuration des services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { 
        Title = "API Pizzéria",
        Description = "Faire les pizzas que vous aimez",
        Version = "v1" 
    });
});

// Remplacer InMemory par SQLite
builder.Services.AddSqlite<PizzaEhodDB>(connectionString);

var app = builder.Build();

// Configuration du middleware
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Pizzéria API V1");
});

// Route par défaut
app.MapGet("/", () => "École Supérieure Polytechnique DIT2 2024");

// GET toutes les pizzas
app.MapGet("/pizzas", async (PizzaEhodDB db) => await db.Pizzas.ToListAsync());

// GET une pizza par ID
app.MapGet("/pizza/{id}", async (PizzaEhodDB db, int id) => await db.Pizzas.FindAsync(id));

// POST nouvelle pizza
app.MapPost("/pizza", async (PizzaEhodDB db, PizzaEhod pizza) =>
{
    await db.Pizzas.AddAsync(pizza);
    await db.SaveChangesAsync();
    return Results.Created($"/pizza/{pizza.Id}", pizza);
});

// PUT mettre à jour une pizza
app.MapPut("/pizza/{id}", async (PizzaEhodDB db, PizzaEhod updatepizza, int id) =>
{
    var pizza = await db.Pizzas.FindAsync(id);
    if (pizza is null) return Results.NotFound();
    
    pizza.Nom = updatepizza.Nom;
    pizza.Description = updatepizza.Description;
    
    await db.SaveChangesAsync();
    return Results.NoContent();
});

// DELETE supprimer une pizza
app.MapDelete("/pizza/{id}", async (PizzaEhodDB db, int id) =>
{
    var pizza = await db.Pizzas.FindAsync(id);
    if (pizza is null)
    {
        return Results.NotFound();
    }
    
    db.Pizzas.Remove(pizza);
    await db.SaveChangesAsync();
    return Results.Ok();
});

app.Run();